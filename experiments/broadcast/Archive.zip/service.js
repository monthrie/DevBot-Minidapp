// service.js
MDS.init(function(msg){
    if(msg.event == "inited"){
        console.log("Service initialized");
        createMessagesTable();
    } else if(msg.event == "MAXIMA"){
        // Handle incoming Maxima messages
        if(msg.data.application == "YourAppName"){
            // Process the message
            let decodedMessage = hexToString(msg.data.data);
            // Store the message using SQL
            let sql = `INSERT INTO messages (timestamp, message) VALUES (${Date.now()}, '${decodedMessage.replace(/'/g, "''")}')`; // Escape single quotes
            MDS.sql(sql, function(res) {
                if (res.status) {
                    console.log("Message inserted successfully");
                    MDS.notify("New message received");
                } else {
                    console.error("Failed to insert message:", res.error);
                }
            });
        }
    }
});

function createMessagesTable() {
    MDS.sql("CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp BIGINT, message TEXT)", function(res) {
        if (res.status) {
            console.log("Messages table created or already exists");
        } else {
            console.error("Failed to create messages table:", res.error);
        }
    });
}

function hexToString(hex) {
    return decodeURIComponent(hex.replace(/\s+/g, '').replace(/[0-9a-f]{2}/g, '%$&'));
}